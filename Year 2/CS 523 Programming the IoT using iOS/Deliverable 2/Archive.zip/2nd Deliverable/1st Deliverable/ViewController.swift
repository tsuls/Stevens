//
//  ViewController.swift
//  1st Deliverable
//
//  Created by Tyler on 7/11/18.
//  Copyright © 2018 Tyler. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var info: UIButton!
    @IBOutlet weak var settings: UIButton!
    @IBOutlet weak var bottomConst: NSLayoutConstraint!
    @IBOutlet weak var weightNumber: UILabel!
    @IBOutlet weak var weightLabel: UILabel!
    @IBOutlet weak var tear: UIButton!
    @IBOutlet weak var menuView: UIView!
    
    
    var menuOpen = false
    var currentUnit = "Grams"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        bottomConst.constant = 62
        menuView.layer.shadowOpacity = 0.5
        menuView.layer.shadowRadius = 0.5
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func PressGear(_ sender: UIButton)
    {
        if menuOpen
        {
            bottomConst.constant = 62
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
        }
        else
        {
            bottomConst.constant = 0
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
        }
        menuOpen = !menuOpen
    }
    
    @IBAction func pressTear(_ sender: UIButton)
    {
        
    }
    @IBAction func pressInfo(_ sender: UIButton)
    {
         let alert = UIAlertController(title: "3D Scale", message: "Place on object on the scale to weigh it.", preferredStyle: .alert)
        
        let dismiss = UIAlertAction(title: "Dismiss", style: .cancel, handler: nil)
        
            alert.addAction(dismiss)
           present(alert, animated: true, completion: nil)
    }
    
    @IBAction func pressPound(_ sender: UIButton)
    {
        
    }
    
    @IBAction func pressOunce(_ sender: UIButton)
    {
        
    }
}

