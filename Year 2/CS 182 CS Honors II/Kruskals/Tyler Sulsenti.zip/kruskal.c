#include "primmst.h"
#include "disjsets.h"
#include <stdlib.h>
#include <stdio.h>
	



struct ed
{
    
    int source;
    int target;
    float weight;
    
};

typedef struct ed* ED;



Graph minSpanTree(Graph g)
{
    Graph graph = makeGraph(numVerts(g), LIST);
    int size = numVerts(g);
	ED* Edges = (ED*) malloc(sizeof(ED) * size * size);
	
    int position = 0;
	for(int i = 0; i < size; i++)
	{
        for( int j = 0; j<size; j++)
        {
            if(edge(g, i, j) != INFINITY)
            {
                Edges[position] = (ED) malloc(sizeof( struct ed));
                Edges[position] -> source = i;
                Edges[position] -> target = j;
                Edges[position] -> weight = edge(g, i, j);	//Get the Set of eges.
                position++;
            }
        }
		
	}

    ED* sortedEdges = (ED*) malloc(sizeof(ED) * position);
    int location = 0;
    for( int i = 0; i<position; i++)
    {
        float smallest = Edges[0] -> weight;
        int pos = 0;
        for( int j = 0; j<position; j++)
        {
            if(Edges[j] -> weight < smallest)
            {
                smallest = Edges[j] -> weight;
                pos = j;
            }
        }
        if(Edges[pos] -> weight != INFINITY)
        {
            sortedEdges[location] = (ED) malloc(sizeof(struct ed));
            sortedEdges[location] -> source = Edges[pos] -> source;
            sortedEdges[location] -> target = Edges[pos] -> target;
            sortedEdges[location] -> weight = Edges[pos] -> weight;
        
            Edges[pos] -> weight = INFINITY;
            location++;
        }
    }
    
    
    DisjSets DJS = makeDisjSets(size);
    int xposition = 0;
    while(numSets(DJS) != 1)
    {
        int n = sortedEdges[xposition] -> source;
        int m = sortedEdges[xposition] -> target;
        
        if(find(DJS, n) != find(DJS, m)){
            make_union(DJS, n, m);
            addEdge(graph, n, m, sortedEdges[xposition] ->weight);
            addEdge(graph, m, n, sortedEdges[xposition] ->weight);
        }
    
        xposition++;
    }
    return graph;
}


