#include "disjsets.h"
#include <stdlib.h>
#include <stdio.h>



struct disjsets
{
	int size;
	int* parents;
}; 
typedef struct disjsets* DisjSets;


DisjSets makeDisjSets(int size)
{
    DisjSets d = (DisjSets) malloc(sizeof(struct disjsets));
    d-> parents = (int*) malloc(sizeof(int)*size);
    d-> size = size;
    for( int i = 0; i<size; i++){
        d -> parents[i] = -1;
    }

	return d;
}

int find(DisjSets d, int n)
{
    
    while(d->parents[n] != -1)
	{
        n = d->parents[n];
	}
    return n;
}

void make_union(DisjSets d, int n, int m)
{
	//Find the parent
    d->parents[find(d,m)] = n;
	d-> size--;
}

int numSets(DisjSets d)
{
	return d-> size;
}
