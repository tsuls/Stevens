//I pledge my honor that i have abided by the Stevens honor system
//Tyler Sulsenti
//Sara Dos Santos
package breakaway;

import javax.swing.*;
import java.awt.*;

public class Paddle extends GameRectangle
{
	public Paddle(int lX, int lY, int width, int height, Color c)
	{
		super(lX,lY,width,height, c);
	}	
	
	/**
	 * Fills the object so it can be painted on the screen	
	 * 
	 * @param g		graphics element for painting
	 */
	public void fill(Graphics g)
	{
		super.fill(g);
	}
}