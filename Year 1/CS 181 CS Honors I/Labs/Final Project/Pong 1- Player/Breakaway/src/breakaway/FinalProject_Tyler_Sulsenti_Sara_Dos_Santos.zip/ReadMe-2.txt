Breakaway Game

Objective: Hit all the blocks to make them disapear.

Instructions: Select Start on the main menu. To begin, press space. You have 3 lives. Don't let the ball go below the paddle or you will lose a life. Move your
	mouse to move the paddle and catch the ball. The ball will bounce off the paddle towards the blocks. Every time you hit a block, it will be destroyed and you 
	will gain 1 point. After every 15 points, you will level up and the ball will begin to move faster. Another way to earn points is with powerups.

Power-ups: There are 2 types of poer-ups in this game: 
		Purple: adds 10 points to your score
		Blue: makes the width of your paddle 4 times greater until you die or for 10 blocks you hit

High Score: You can click High Scores on the main menu to view the high scores. After you lose, if you got a high score, you will be promted to enter your initials
	(three character maximum) and then you will be taken to the high score page. If you lose and did not get a high score, you can click to view the high scores 
	and then go back to the main menu.

To exit the game, press Exit on the main menu.


Tyler Sulsenti
Sara Dos Santos